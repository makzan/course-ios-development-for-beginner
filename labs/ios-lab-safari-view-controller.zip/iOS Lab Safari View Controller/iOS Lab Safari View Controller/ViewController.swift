//
//  ViewController.swift
//  iOS Lab Safari View Controller
//
//  Created by makzan on 2019-03-18.
//  Copyright © 2019 makzan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func openExternalWebsite(_ sender: Any) {
        
    }
    
}

