//
//  ViewController.swift
//  iOS Lab SafariViewController
//
//  Created by cm420-03-2019-c on 18/3/2019.
//  Copyright © 2019年 CPTTM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func openExternalWebsite(_ sender: Any) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

